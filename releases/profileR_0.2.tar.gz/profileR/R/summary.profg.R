
#'@S3method summary profg

summary.profg <- function(object, ...){
	cat("Call:\n")
	print(object$call)
	cat("\nHypothesis Tests:\n")
	print(object$profile.test)
}

